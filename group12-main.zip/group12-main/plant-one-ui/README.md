# plant-one-ui

## Node version
v16.14.0

## npm version
8.5.3

## Install Vue CLI
```
npm install -g @vue/cli
```

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for testing instance
```
npm run build:testing
```

### Compiles and minifies for production instance
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

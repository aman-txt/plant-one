import Vue from 'vue'
import BtnLoader from "@/views/Widgets/BtnLoader"

Vue.component('BtnLoader', BtnLoader)
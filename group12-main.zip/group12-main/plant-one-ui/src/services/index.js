
import { default as APIs } from "./apis"

let apisObject = APIs;
function getApiObject(){
   return apisObject
}
 export default getApiObject()

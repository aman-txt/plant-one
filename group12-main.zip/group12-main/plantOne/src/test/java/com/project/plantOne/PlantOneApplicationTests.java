package com.project.plantOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantOneApplicationTests {

	@Test
	void contextLoads() {
	}

}

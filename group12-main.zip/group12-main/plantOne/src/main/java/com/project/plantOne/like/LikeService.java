package com.project.plantOne.like;

import java.util.UUID;

public interface LikeService {


    public String likesClick(UUID postUUID, UUID userUUID);


}

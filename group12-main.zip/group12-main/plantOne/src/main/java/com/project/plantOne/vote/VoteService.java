package com.project.plantOne.vote;

import java.util.UUID;

public interface VoteService {


    public String upVoteClick(UUID blogUUID, UUID userUUID);
}

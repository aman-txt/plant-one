# PlantOne

#### Application URL

Production application URL
```sh
https://plantoneuiproduction.herokuapp.com/#/login
```

Production backend swagger ui

```sh
 https://plantoneproduction.herokuapp.com/swagger-ui.html#/
```
Testing application URL
```sh
https://plantoneuitesting.herokuapp.com/#/login
```

Testing backend swagger ui

```sh
https://plantonetesting.herokuapp.com/swagger-ui.html#/
```

